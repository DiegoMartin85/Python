"""
Tuplas >>> Tuple

Tuplas, uma vez criada, não aceitam modificações. 

Tupla(em outras linguagens de programações são
chamadas de "constante")

Sintaxe's
variável = ()
variável = tuple()

Tuplas são definidas por uso de parenteses.

Métodos de adição, remoção, alteração, ordenação em tuplas não existem.

"""

# tupla como criar







