'''
CENÁRIO
=======

Cálculo de Impostos com Desconto e Entrada de Produtos
------------------------------------------------------

Uma empresa deseja automatizar o processo de cálculo de 
impostos sobre produtos vendidos, considerando também 
eventuais descontos aplicados ao consumidor.

Pede-se crie um programa para:
-----------------------------

1) Solicite ao usuário quantos produtos deseja cadastrar.

2) Para cada produto, o usuário deve informar:

    Nome do produto

    Preço original (antes do desconto)

    Valor do desconto aplicado ao produto


3) O programa deve calcular:

    a) O valor dos impostos (IR, ISS, CSLL) com base no preço original

    b) IR (Imposto de Renda):

            20% para produtos com preço até R$ 2.000,00

            30% para produtos com preço acima de R$ 2.000,00

    c) ISS: 15% do preço original

    d) CSLL: 5% do preço original

    e) O preço final com desconto

4) Para cada produto, exibir:

    Nome do produto

    Preço original (formatado como moeda brasileira)

    Valor do desconto

    Preço final com desconto

    Valor total dos impostos calculados

'''
# seu código aqui

# 2o passo - Função 
# sempre que criar uma função coloque no inicio do programa
# caso contrário a funçao não será executada
# def = definir / criar





######### 1o passo - Início do Programa #########
iss = 0.15 # 15%
csll = 0.05 # 5%

# Looping(FOR) que repete o processo para cada produto informado
quantidades_produtos = int(imput('Quantos produtos deseja cadastrar: '))

for numero_produto in range(quantidades_produtos):

    print(f'Produto: {numero_produto + 1}')

    # coletar o nome do produto
    nome_produto = input('Digite o nome do produto: ')

    preco = float(input('Digite o preço do produto: '))

    desconto = float(input('Digite o valor do desconto: '))/100

    # cálculos
    imposto_total = vamos criar a função 




































































