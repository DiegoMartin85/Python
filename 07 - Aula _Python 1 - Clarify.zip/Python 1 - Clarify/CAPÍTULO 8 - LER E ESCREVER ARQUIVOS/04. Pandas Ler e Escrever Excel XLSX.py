# 1o passo - chamar a biblioteca pandas
import pandas as pd 

# lib serve para trabalhar com Windows
import os 

# 2o passo - Local do arquivo Excel
caminho = r"C:\Users\noturno\Desktop\Diego Martin\Python 1 - Clarify\CAPÍTULO 8 - LER E ESCREVER ARQUIVOS\Arquivo 1.xlsx"

# 3o passo - usar arquivo para pegar o número da aba
excel = pd.ExcelFile(caminho)

# 4o passo - número da aba
numero_da_aba_arquivo = 0

# 5o passo - ao capturar o número da aba, ou seja, 
# sheet_name podemos identificar o nome dela
# a posição da aba dentro da planilha não pode ser alterada
# caso contrário o programa dá erro!
# Planilha 1
nome_aba = excel.sheet_names[numero_da_aba_arquivo]

print(f'Primeira aba: {nome_aba}')

if nome_aba != 'Planilha 1':
    print('A aba [Planilha 1] precisa ser a primeira!')
    print('O programa será encerrado...')
else:
    print('A aba está na posição correta...processando...')

# 6o passo - ler a planilha pelo índice da aba (número)
df = pd.read_excel(caminho, sheet_name=numero_da_aba_arquivo)


# 7o passo - adicionar umva nova coluna [Aumento 30%]
# se a coluna [Valor] não existe dentro do DataFrame(tabela)
if 'Valor' not in df.columns: 
    print('Coluna[Valor] não existe!')
    exit() # programa será encerrado aqui
else: 
    # se a coluna 'Valor Aumento' não existe dentro do DataFrame
    # então crie a coluna
    if 'Valor Aumento' not in df.columns:
        df['Valor Aumento'] = df['Valor'] * 1.30
        print('Coluna [Valor Aumento] criada com sucesso!')
    else: 
        print('Coluna [Valor Aumento] já existe dentro do Arquivo')

# 8o passo - escrever os da memória do DataFrame, no próprio Excel
# sheet_name=nome_aba, ou seja, "Planilha 1" que está dentro do arquivo
# obrigatoriamente precisa ser texto(string)
try:
    df.to_excel(caminho, index=False, sheet_name=nome_aba, float_format='%.2f')

except Exception as DescricaoDoErro:
    print(f'Descrição do Erro: {DescricaoDoErro}')
    print('O programa será encerrado...')
    exit()
# 9o passo - abrir o arquivo onde ele está 
os.startfile(caminho)




























