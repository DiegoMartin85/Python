'''
Enunciado do Exercício: Herança Empresa de Tecnologica

Você foi contratado para criar um sistema simples de cadastro 
de empresas. Sua tarefa é implementar duas classes em Python
utilizando o conceito de herança:

Requisitos
==========
1. Classe base: Empresa
    A classe Empresa deve conter:

    Atributos:

        nome: nome da empresa

        cnpj: número do CNPJ

        funcionarios: lista de nomes de funcionários (inicialmente vazia)

    Métodos:

        __init__(self, nome, cnpj): construtor

        adicionar_funcionario(self, nome_funcionario): adiciona um nome à lista de funcionários

        exibir_dados(self): mostra nome, CNPJ e quantidade de funcionários

2. Classe filha: EmpresaTecnologica

    A classe EmpresaTecnologica deve herdar da classe Empresa.

    Atributos adicionais:

        tecnologias: lista de tecnologias que a empresa usa

    Métodos adicionais:

        __init__(self, nome, cnpj, tecnologias): deve usar super() para aproveitar o construtor da classe base

        exibir_tecnologias(self): imprime a lista de tecnologias



'''

class Empresa: 

    # construtor (da classe principal)
    def __init__(self, nome, cnpj):
        
        self.nome = nome
        self.cnpj = cnpj
        self.funcinarios = [] # lista vazia

    # método para adicionar funcionários
    def adicionar_funcionario(self, nome_funcionario):
        self.funcinarios.append(nome_funcionario)
        print(f'Funcionário: {nome_funcionario} cadastrado!')
    
    # método para exibir os dados da empresa:
    def exibir_dados(self):
        print(f'Nome da empresa: {self.nome}')
        print(f'CNPJ: {self.cnpj}')
        print(f'Número de funcionários: {len(self.funcinarios)}')

# sai da Classe Principal
# classe filha que herda tudo da classe Empresa
class EmpresaTecnologia(Empresa):

    # construtor da classe filha 
    def __init__(self, nome, cnpj, tecnologias):

        # chama o construtor da classe base(filha)
        # o super() é usado para acessar os métodos ou atributos
        # da classe principal
        super().__init__(nome, cnpj)

        self.teconologias = tecnologias # atributo da classe filha

    # método específico da classe filha para exibir tecnologias
    def exibir_tecnologias(self):
        print(f'Tecnologias utilizadas pela empresa: {self.nome}')
        
        for tecnologia in self.teconologias:
            print(f'Teconologia: {tecnologia}')


# INICIO DO PROGRAMA
empresa_tec = EmpresaTecnologia('Inovatech', '11.123.456/0001-88',
                ['Python', 'Inteligência Artificial', 'Clud(nuvem)'])

# adicionar funcionários
empresa_tec.adicionar_funcionario('Lucas')
empresa_tec.adicionar_funcionario('Juliana')

# exibir os dados da empresa
empresa_tec.exibir_dados()

#exibir as tecnologias
empresa_tec.exibir_tecnologias()














































































































