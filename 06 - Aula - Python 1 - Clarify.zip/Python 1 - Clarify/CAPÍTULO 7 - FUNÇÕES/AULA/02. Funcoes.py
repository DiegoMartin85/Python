'''
CENÁRIO
=======

Cálculo de Impostos com Desconto e Entrada de Produtos
------------------------------------------------------

Uma empresa deseja automatizar o processo de cálculo de 
impostos sobre produtos vendidos, considerando também 
eventuais descontos aplicados ao consumidor.

Pede-se crie um programa para:
-----------------------------

1) Solicite ao usuário quantos produtos deseja cadastrar.

2) Para cada produto, o usuário deve informar:

    Nome do produto

    Preço original (antes do desconto)

    Valor do desconto aplicado ao produto


3) O programa deve calcular:

    a) O valor dos impostos (IR, ISS, CSLL) com base no preço original

    b) IR (Imposto de Renda):

            20% para produtos com preço até R$ 2.000,00

            30% para produtos com preço acima de R$ 2.000,00

    c) ISS: 15% do preço original

    d) CSLL: 5% do preço original

    e) O preço final com desconto

4) Para cada produto, exibir:

    Nome do produto

    Preço original (formatado como moeda brasileira)

    Valor do desconto

    Preço final com desconto

    Valor total dos impostos calculados

'''
# seu código aqui







































































