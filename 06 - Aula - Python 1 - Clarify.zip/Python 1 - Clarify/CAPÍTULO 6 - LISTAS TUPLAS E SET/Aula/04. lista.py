'''
    LISTAS: 
        Adição 
        Remoção 
        Alteração de valores
        Ordenação

        
        * APPENDD >>> Atribui a lista, um elemento por vez. 
        * INSERT >>> Atribui vários elementos, integrando à lista original.
        * POP >>> Remove um valor da lista por índice.
        * REMOVE >>> Remove um valor da lista por valor.
        * SORT >>> Ordena os dados de uma lista.
        

'''

# Gerencimanto de estoque com listas
# escreva seu código abaixo
produtos = ['monitor', 
            'notebook',
            'teclado',
            'mouse']

print('Estoque inicial:')
print(produtos)

# adicionar novos podutos
produtos.append('impressora') #adicionar no final
print(f'Produto impressora adicionado(.append): {produtos}')

# adiciona na 2a posição
produtos.insert(2, 'headset') # adicionar na segunda posição
print(f'Produto headset inserido(.insert): {produtos}')

# remover produtos
produtos.remove('mouse') # remove pelo nome
print(f'Produto mouse retirado(.remove): {produtos}')

# remover pelo índice(posição) 1
removido = produtos.pop(1)

print(f'Produto removido(.pop): {removido}')
print(f'Estoque após a remoção: {produtos}')

# alteração de produtos
# altera o primeiro item
produtos[0] = 'monitor led'

# altera o último item
produtos[-1] = 'impresoar a laser'

print(f'Após alteração: {produtos}')

# ordenação dos produtos
# ordenar em ordem alfabética [A-Z]
produtos.sort()
print('Produtos em ordem alfabética [A-Z]')
print(produtos)

# ordenação reversa [Z-A]
produtos.sort(reverse=True)
print('Produtos em ordem reversa: [Z-A]')
print(produtos)














































































