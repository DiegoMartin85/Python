
"""
IF,   = (significa SE)
ELIF, = (significa SENÃO SE)
ELSE  = (significa SENAO)

Permite que o código siga por caminhos diferentes
de acordo com resultado de análises, equações e etc.

Resumo: tomar decisões lógicas com base em diferentes cenários

    Tabela - Operadores Relacionais

            ==	Igual a
            !=	Diferente
            >=	Maior ou igual
            >	Maior que
            <	Menor que
            <=	Maior ou igual
    
    Operadores Lógicos

            or	OU lógico
            and	E lógico
            not	Negação
"""


# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

# Biblioteca: DATETIME

# https://docs.python.org/3/search.html?q=datetime

# *****************************************

# Escreva seu código aqui

# 1o passo - Entradas - variáveis
from datetime import date

# .today() = 2025-08-18 (padrão Americano yyyy-MM-dd)
data_atual = date.today().strftime('%d/%m/%Y')
print(f'Data atual: {data_atual}')

# 2o passo - cálculos
nota1 = float(input('Nota 1: '))
nota2 = float(input('Nota 2: '))
nota3 = float(input('Nota 3: '))
nota4 = float(input('Nota 4: '))

media = sum([nota1, nota2, nota3, nota4]) / 4

# 3o passo - tomar decisões com IF´s
if media >= 7 and media <= 10:
        print(f'Aprovado sua média é: {media:.2f}')
#senão se
elif media >= 5 and media < 7:
        print(f'Recuperação sua média é: {media:.2f}')
#senão se
elif media >=0 and media < 5:
        resposta = input('Seu boletim foi assinado ? [S/N]: ').lower()
                
        if resposta not in ('s', 'n'):
                print('Por favor, digite apenas S ou N.')
                exit() #encerrar o programa
        else:
                if resposta == 's':
                        print('OK, aluno reprovado!')
                elif resposta == 'n':
                        print('Certo, vou entrar em contato com os responsáveis!')
                else: 
                        print('Opção inválida!')
else: 
        print(f'Média inválida! Foi calcualada a média: {media:.2f}')































































































































