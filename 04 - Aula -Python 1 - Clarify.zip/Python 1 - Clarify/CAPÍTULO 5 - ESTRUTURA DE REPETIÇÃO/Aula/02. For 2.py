""" 
Calcular o Salário Anual

Pede-se:

Solicitar ao usuário o salário mensal inicial
e o percentual de aumento mensal.
Usar o laço for para calcular o salário 
acumulado mês a mês ao longo de 12 meses.
Exibir o salário de cada mês e o total ao final.


Entrada
=======

    Digite o salário mensal inicial: 2000
    Digite o aumento percentual mensal: 2

    SAÍDA
    =====
    Mês 1: 000.00
    Mês 2: 000.00
    Mês 3: 000.00
    Mês 4: 000.00
    ...
    Mês 12: 000.00
    Salário total no ano: R$ 000.00
    
 """

'Escreva seu código aqui'

# 1o passo - Salario mensal
salario_mensal = input('Digite o salário no formato ex.: 000.000,00: ')

# 2o passo - vamos usar a função .Replace()
# deixar no padrão Americano para calculos
valor_formatado = salario_mensal.replace('.','').replace(',','.')

# 3o passo - converter para float
sal_mensal = float(valor_formatado)

# 4o passo - percentual do aumento
percentual_aumento = float(input('Digite o percentual: '))

# 5o passo - converter o percentual em decimal
# 0.02
# tradução: percentual_aumento = percentual_aumento / 100
percentual_aumento /= 100

# 6o passo - inicializar o total acumulado com zero (0)
# caso contrário vai dar erro do FOR
# motivo: é uma variavel totalizadora
salario_total = 0

# 7o passo - exibir uma mensagem
print('\nSalários ao longo dos 12 meses: ')

# 8o passo - calcular os salários mês a mês
# range( 1, 12 ) = irá até o 12 mês (13-1=12)
# range(início, limite)
for mes in range(1,13):

    match mes:
        case 1:
            nome_do_mes = 'Janeiro'
        case 2:
            nome_do_mes = 'Fevereiro'
        case 3:
            nome_do_mes = 'Março'
        case 4:
            nome_do_mes = 'Abril'
        case 5:
            nome_do_mes = 'Maio'
        case 6:
            nome_do_mes = 'Junho'
        case 7:
            nome_do_mes = 'Julho'
        case 8:
            nome_do_mes = 'Agosto'
        case 9:
            nome_do_mes = 'Setembro'
        case 10:
            nome_do_mes = 'Outubro'
        case 11:
            nome_do_mes = 'Novembro'
        case 12:
            nome_do_mes = 'Dezembro'
    
    # ainda estou dentro do FOR
    # 2,000.00
    print(f'Mês {nome_do_mes} : R$ {sal_mensal:,.2f}'.replace(',','texto').replace('.',',').replace('texto','.'))


    # a variável salario_total é utlizada para obter o total acumulativo
    # dos períodos
    salario_total = salario_total + sal_mensal

    sal_mensal = sal_mensal + (sal_mensal * percentual_aumento)

# sai do FOR (looping)

# 9o passo - formatar o total acumulativo dos períodos 
salario_total_formatado = f'{salario_total:,.2f}'.replace(',','texto').replace('.',',').replace('texto','.')

# 10 passo - exibir salario total
print(f'Total salarioal ao longo do ano: R$ {salario_total_formatado}')



































































































