"""
   1) Pede-se:
   ===========
      crie as seguintes variaveis:

         matricula
         nome
         salario
         qtde filhos

      ENTRADA
      =======
         matricula =  deverá receber somente números

         nome = deverá receber somente textos

         salario = deverá receber somente valor decimal

         qtde filhos = deverá receber somente números

      SAÍDA
      =====
      faça exibir os valores digitados em cada variável

"""

# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

'Escreva seu código abaixo'

matricula = int(input('Digite sua matricula:'))
nome = input('Digite seu nome: ')
salario = float(input('Digite seu salário: '))
qte_filhos = int(input('Digite o número de filhos: '))

print(f'A matrícula é: { matricula}')
print(f'O nome é: {nome}')
print(f'Salário: {salario}')
print(f'Número de filhos: {qte_filhos}')





















