'''
    While com Break
    while True: >>> este laço será executado enquanto 
    não encontrar o Break pelo caminho.
    Break >>> Condição de parada/encerramento(stop) de um loop. 

'''
# Escreva seu código aqui



































