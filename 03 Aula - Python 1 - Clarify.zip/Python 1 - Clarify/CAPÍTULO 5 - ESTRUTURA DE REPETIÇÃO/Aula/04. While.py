'''
    Pede-se cadastro de senha

    ENTRADAS:
        senha cadastrada
        senha entrada
    
    PROCESSAMENTO:
        enquanto a senha cadastrada for diferente 
        da senha de entrada continue e verificação(Looping)

    SAIDA:
        quando a senha de cadastrada for igual a senha de entrada
        exibir "Acesso Permitido"

'''
# Escreva seu código aqui
# 1o passo - validar a senha - Entradas




# 2o passo - validar
# enquanto senha cadastrada for diferente da senha entrada, 
# continue o Looping(While)
# != significa operador para validar se as variáveis são diferentes






# 3o passo - permitir acesso
























































































