""" 
Calcular o Salário Anual

Pede-se:

Solicitar ao usuário o salário mensal inicial
e o percentual de aumento mensal.
Usar o laço for para calcular o salário 
acumulado mês a mês ao longo de 12 meses.
Exibir o salário de cada mês e o total ao final.


Entrada
=======

    Digite o salário mensal inicial: 2000
    Digite o aumento percentual mensal: 2

    SAÍDA
    =====
    Mês 1: 000.00
    Mês 2: 000.00
    Mês 3: 000.00
    Mês 4: 000.00
    ...
    Mês 12: 000.00
    Salário total no ano: R$ 000.00
    
 """

'Escreva seu código aqui'































































































