"""
    SISTEMA DE VENDAS.
        Nesta etapa da vida, vamos lidar apenas 
        com o cadastro do produto.

    ENTRADA:
        Nome do produto. 
        Preço de custo.
        Percentual de lucro.
        Qtd vendida para análisar lucro.

    PROCESSAMENTO:
        Calcular o preço de venda com base no preço de 
        custo e no % de lucro

        Calcular e aplicar os seguintes impostos sobre 
        o preço de venda:

            ICMS: 18%
            PIS: 1.65%
            COFINS: 7.6%
            IPI: 10%

        Calcular o preço final do produto com impostos. 
        Calcular a margem de lucro percentual sobre o preço de venda.
        Calcular o lucro total vendendo 100 unidades do produto.

    SAÍDA:
        Nome do produto.
"""

# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

# Escreva seu código abaixo

# 1o passo - Entradas - variáveis e seus tipos de dados
nome_produto = input('Nome do produto: ').upper()
preco_custo = float(input('Preço de custo: '))
percentual_de_lucro = float(input('Lucro(%): ')) # qual percentual
qtde_vendida = int(input('Quantidade vendida, digite no mínimo 100: '))

# 2o passo - Processamento - cálculos
preco_venda = preco_custo * (1 + percentual_de_lucro / 100)

# 3o passo - Atribuir os impostos as variáveis
percentual_icms = 18
percentual_pis = 1.65
percentual_cofins = 7.6
percentual_ipi = 10

# 4o passo - Calcular o preço final do produto com impostos
valor_icms = preco_venda * (percentual_icms / 100)
valor_pis = preco_venda * (percentual_pis /100)
valor_cofins = preco_venda * (percentual_cofins / 100)
valor_ipi = preco_venda * (percentual_ipi / 100)

total_impostos = valor_cofins + valor_icms + valor_ipi + valor_pis

preco_final = preco_venda + total_impostos

lucro_total = (preco_final - preco_custo - total_impostos) * qtde_vendida

margem_lucro_percentual = lucro_total / (preco_venda * qtde_vendida)

receita_bruta = preco_final * qtde_vendida

receita_liquida = preco_venda * qtde_vendida

# 5o passo - Saídas (exibir os resultados)
print('\nResumo do Produto')
print('===========================')
print(f'Nome do produto: {nome_produto}')
print(f'Preço de custo: {preco_custo:.2f}')
print(f'Percentual e lucro desejado: {percentual_de_lucro:.2f}')

print('\n') #pular 1 linha no terminal

print('Cálculos de Preço e Impostos')
print(f'Preço de venda: {preco_venda:.2f}')

print('\n') #pular 1 linha no terminal

print('Impostos Aplicados')
print(f'ICMS {percentual_icms}% - R$ {valor_icms:.2f}')
print(f'COFINS {percentual_cofins}% - R$ {valor_cofins:.2f}')
print(f'IPI {percentual_ipi}% - R$ {valor_ipi:.2f}')
print(f'PIS{percentual_pis}% - R$ {valor_pis:.2f}')

print(f'Preço final com impostos: R$ {preco_final:.2f}')

print('\n') #pular 1 linha no terminal

print('Lucro e Margem de Lucro')
print(f'Lucro total vendido]: {qtde_vendida} unidades R$ {lucro_total:.2f}')

print(f'Receita Bruta: {receita_bruta:.2f}')
print(f'Receita Liquida: {receita_liquida:.2f}')







































