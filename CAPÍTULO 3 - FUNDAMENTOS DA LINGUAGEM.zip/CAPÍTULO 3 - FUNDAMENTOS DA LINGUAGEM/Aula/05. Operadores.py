"""
    SISTEMA DE VENDAS.
        Nesta etapa vamos lidar apenas com o 
        cadastro do produto.

    CRIE AS VARIÁVEIS DE ## ENTRADA ##
        Nome do produto. 
        Preço sem desconto
        Porcentagem de desconto

    ## PROCESSAMENTO ##
        Calcule o novo preço do produto com desconto

    VARIÁVEIS DE ## SAÍDA ##
        Nome do produto.
        Preço com desconto.
"""

# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

#Escreva seu código abaixo

# 1o passo - Entradas - variáveis
nome_produto = input('Digite o produto: ')
preco = float(input('Preço sem desconto: '))
desconto = float(input('Percentual de desconto(%): ')) #10
produto_estoque = True

# 2o passo - Processamento
valor_desconto = preco * desconto / 100
preco_com_desconto = preco - valor_desconto

# 3o passo - Saídas / Resultados
print('\nResumo do produto')
print(f'Nome do produto: {nome_produto}')
print(f'Preço com desconto: {preco_com_desconto:.2f}')

# se o conteúdo da variável produto_estoque for (True) então,
# exibir a mensagem: Produto no estoque!
if produto_estoque == True:
    print('Produto no estoque!')
else: #senão
    print('Produto fora do estoque!')














