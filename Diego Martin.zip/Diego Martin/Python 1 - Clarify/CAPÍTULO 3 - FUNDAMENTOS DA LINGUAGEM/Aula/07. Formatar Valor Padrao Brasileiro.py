
'''
Exemplo de entrada e saída:
===========================
Entrada: 1.000,00
Saída: O valor convertido para cálculo é: 1000.0

Detalhes adicionais:
====================
Esse processo de substituição é essencial para garantir que o Python 
interprete corretamente o valor, já que ele não reconhece automaticamente 
os separadores de milhar e decimal no formato brasileiro. 
Esse método é eficiente e pode ser utilizado sempre que você 
receber valores no formato 1.000,00.

Explicação:
==========
input(): Captura o valor digitado pelo usuário, que pode estar no formato 1.000,00 por exemplo.
1º replace('.', ''): Remove os pontos, que são usados no Brasil para separar os milhares.
2º replace(',', '.'): Substitui a vírgula por ponto, porque o Python usa ponto como separador decimal.
float(): Converte a string formatada para um número decimal(ponto flutuante), permitindo o uso em cálculos matemáticos.

'''

# 1o passo - Entradas



# 2o passo - remover os pontos (separadores de milhar) e substituir a vírgula
# por ponto ( separador de decimal )
# 1890.12
# transformar o valor para leitura do Python(padrão Americano 1890.12)


 
# 3o passo - converter para float


# 4o passo - calcular 10% de desconto no valor informado


# 5o passo - calcular o valor final om o desconto


# 6o passo - exibir os resultados

































