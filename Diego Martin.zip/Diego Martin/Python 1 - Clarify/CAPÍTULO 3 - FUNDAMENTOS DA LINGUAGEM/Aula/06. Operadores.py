"""
    SISTEMA DE VENDAS.
        Nesta etapa da vida, vamos lidar apenas 
        com o cadastro do produto.

    ENTRADA:
        Nome do produto. 
        Preço de custo.
        Percentual de lucro.
        Qtd vendida para análisar lucro.

    PROCESSAMENTO:
        Calcular o preço de venda com base no preço de 
        custo e no % de lucro

        Calcular e aplicar os seguintes impostos sobre 
        o preço de venda:

            ICMS: 18%
            PIS: 1.65%
            COFINS: 7.6%
            IPI: 10%

        Calcular o preço final do produto com impostos. 
        Calcular a margem de lucro percentual sobre o preço de venda.
        Calcular o lucro total vendendo 100 unidades do produto.

    SAÍDA:
        Nome do produto.
"""

# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

# Escreva seu código abaixo

# 1o passo - Entradas - variáveis e seus tipos de dados




# 2o passo - Processamento - cálculos




# 3o passo - Atribuir os impostos as variáveis




# 4o passo - Calcular o preço final do produto com impostos





# 5o passo - Saídas (exibir os resultados)





































