"""
    SISTEMA DE VENDAS.
        Nesta etapa vamos lidar apenas com o 
        cadastro do produto.

    CRIE AS VARIÁVEIS DE ## ENTRADA ##
        Nome do produto. 
        Preço sem desconto
        Porcentagem de desconto

    ## PROCESSAMENTO ##
        Calcule o novo preço do produto com desconto

    VARIÁVEIS DE ## SAÍDA ##
        Nome do produto.
        Preço com desconto.
"""

# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

#Escreva seu código abaixo

# 1o passo - Entradas - variáveis




# 2o passo - Processamento




# 3o passo - Saídas / Resultados















