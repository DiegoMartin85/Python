"""
   1) Pede-se:
   ===========
      crie as seguintes variaveis:

         matricula
         nome
         salario
         qtde filhos

      ENTRADA
      =======
         matricula =  deverá receber somente números

         nome = deverá receber somente textos

         salario = deverá receber somente valor decimal

         qtde filhos = deverá receber somente números

      SAÍDA
      =====
      faça exibir os valores digitados em cada variável

"""

# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

'Escreva seu código abaixo'
























