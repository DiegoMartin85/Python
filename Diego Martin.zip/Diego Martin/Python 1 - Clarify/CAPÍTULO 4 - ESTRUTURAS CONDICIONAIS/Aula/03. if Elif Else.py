
"""
IF,   = (significa SE)
ELIF, = (significa SENÃO SE)
ELSE  = (significa SENAO)

Permite que o código siga por caminhos diferentes
de acordo com resultado de análises, equações e etc.

Resumo: tomar decisões lógicas com base em diferentes cenários

    Tabela - Operadores Relacionais

            ==	Igual a
            !=	Diferente
            >=	Maior ou igual
            >	Maior que
            <	Menor que
            <=	Maior ou igual
    
    Operadores Lógicos

            or	OU lógico
            and	E lógico
            not	Negação
"""


# Bibliotecas do Python:
# https://docs.python.org/3/library/index.html
# https://docs.python.org/3/library/stdtypes.html#str.format

# Biblioteca: DATETIME

# https://docs.python.org/3/search.html?q=datetime

# *****************************************

# Escreva seu código aqui

# 1o passo - Entradas - variáveis



# .today() = 2025-08-18 (padrão Americano yyyy-MM-dd)




# 2o passo - cálculos




# 3o passo - tomar decisões com IF´s





























































































































