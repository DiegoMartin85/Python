"""
    Estrutura condicionais mais utilizada em menus,
    funciona semelhante ao escolha Caso do portugol
    e switch case no java por exemplo...
"""
# Calculadora

# Escreva seu código aqui































